document.getElementById("year").textContent=new Date().getFullYear();
const menuBtn=document.getElementById("menuBtn"),nav=document.getElementById("navLinks");
menuBtn.addEventListener("click",()=>{nav.style.display=nav.style.display==="flex"?"none":"flex"});
document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>{if(innerWidth<=800)nav.style.display="none"}));
document.getElementById("contactForm").addEventListener("submit",function(e){
 e.preventDefault();
 document.getElementById("formMsg").textContent="संदेश तैयार है। वास्तविक संदेश भेजने के लिए इस form को किसी email/form service से जोड़ना होगा।";
 this.reset();
});
